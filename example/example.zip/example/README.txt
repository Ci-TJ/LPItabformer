# File description.

##1 dsuTab_cz.ipynb code for model training, which mainly needs to be modified depending on the location of the input file you are using.

##2 ft_transformer.py model code, utils2.py model performance indicator functions.

##3 data/ input data, then you need to focus on other_data/README.txt.

##4 Training saved models under win10 in data/LPI500684_seed1_randp1/result/model/ and data/LPI346223_seed1_randp1/result/model/. The trained model could be not available and need to be retrained.
The corresponding input pairs are in data/LPI500684_seed1_randp1/*.txt and data/LPI346223_seed1_randp1/*.txt.