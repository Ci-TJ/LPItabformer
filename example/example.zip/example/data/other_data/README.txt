# File description.

##1 1mer*.csv and 3mer_*.csv lncRNA transcriptome and proteome kmer data, respectively, used to train the model. Where mus denotes mouse (corresponding to LPI346223) and hsa denotes human (LPI500684, or LPI250342). 
The files are incomplete owning to the size limit in GitHub, you need base on the article to generate these files.

##2 predict_cs_malat1.ipynb is a case where I used the trained mouse model and then predicted it, as a subsequent reference for predicting new data output using the trained model. It's not organized and the code is messy.

##3 requirement.txt The version of the package installed in my environment, the package that needs special attention is local-attention .

##4 UP*_cluster.tsv is the clustering grouping situation file for lncRNA transcriptome and proteome.

##5 tool_sample.csv is the kmer file for randomly generating lncRNA-protein role pairs for subsequent testing of input data for wrapper prediction. Note that our model needs to transform these kmer data, just for the convenience of the user.
Therefore the use of tentative input data is the kmer matrix.
